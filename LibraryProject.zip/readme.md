# MY LIBRARY SYSTEM

## This system written in python, using flask, SQLalchemy, REST API, 


# customer functions:
### add a customer - done and works
### display customers - done and works
### unactive customer - done 

## books:
### display books -only active books - done and works
### search for a book by name- done
### deactive book - done
### add a book - done

# loans:

### loan a book - written, type of loan and update return date - done 
### return a book - done
### display active books - done
### display late loans

  ## after I understand  the Authorization ann Authentication I'll  cuntinue and add to project
  ## Also in plan ... to add option of adding images to each book.








